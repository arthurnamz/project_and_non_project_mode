# 2026-01-03T05:36:09.410280
import vitis

client = vitis.create_client()
client.set_workspace(path="sw")

vitis.dispose()

